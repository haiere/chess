package dev.isahajir.chess;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
